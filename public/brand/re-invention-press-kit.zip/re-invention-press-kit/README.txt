re-invention press kit

logo/    The lockup: the loop symbol with the RE-INVENTION wordmark
symbol/  The loop symbol on its own
Each comes in black (for light backgrounds) and white (for dark backgrounds),
as SVG (vector, preferred) and as transparent PNG.

Using the logo
- Use these files as they are. Keep the symbol, letterforms, spacing and
  aspect ratio together; do not redraw, recolour, stretch or rotate them.
- Clear space: let x be the height of the capital letters. Keep at least half
  of x free around the full lockup, and x beside other graphics.
- Minimum width: 240 px on screen, 55 mm in print. Below that, use the symbol.

Questions: michel@re-invention.nl
re-invention.nl
